package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        int[] v = new int[50];
        int sum = 0;
        int i = 0;
        System.out.println("Cate numere doriti sa introduceti? ");
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        for (i = 0; i < n; i++) {
            System.out.print("v[" + i + "]= ");
            v[i] = sc.nextInt();
        }
        sum(v,0, 0);
    }

    public static void sum(int[] v,int i ,int sum) {
        if (i < v.length) {
            sum += v[i];
            i++;
            sum(v,i,sum);
        }
        else{
            System.out.println(sum);}

    }


}