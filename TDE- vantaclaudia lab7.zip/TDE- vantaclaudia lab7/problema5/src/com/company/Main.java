package com.company;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws IOException {

        boolean t = true;
        String d;
        System.out.println(
                "- A - Conversie din baza 10 in baza 2 \n" +
                        "- B - Tiparirea nodurilor in ordine inversa \n" +
                        "- C - Tiparirea elementelor din tablou in ordine inversa \n" +
                        "- D - Copierea în ordine inversă a liniilor dintr-un fisier text, în altul.    \n" +
                        "- X - Paraseste programul. \n ");
        Scanner sc = new Scanner(System.in);
        while (t) {
            System.out.print("In ce meniu doriti sa intrati? ");
            String c = sc.nextLine();
            d = c.toUpperCase();
            switch (d) {

                case "A":
                    int number;
                    Scanner console = new Scanner(System.in);
                    System.out.println("Numarul ales este: ");
                    number = console.nextInt();
                    System.out.println(Convert(number));
                    break;
                case "C":
                    int[] arr = {1,2,3,4,5,6};
                    Tabel(arr,arr.length,arr.length-1);
                    break;
                case "B":
                    List<String> al=new ArrayList<String>();
                    al.add("Ala");
                    al.add("bala");
                    al.add("porto");
                    al.add("cala");
                    Lista(al,al.size()-1);

                    break;
                case "D":
                    BufferedReader reader = new BufferedReader(new FileReader("input.txt"));
                    List<String> fileStream = Files.readAllLines(Paths.get("input.txt"));
                    int index = fileStream.size();
                    System.out.println(fileStream);
                    BufferedWriter writer = new BufferedWriter(new FileWriter("output.txt"));
                    List<String> outputstream = new ArrayList<>();
                    Fisier(fileStream,outputstream,index-1);
                    for(String line:outputstream)
                    {
                    writer.write(line);
                        writer.newLine();}
                    reader.close();

                    writer.close();

                    break;
                case "x":
                    System.exit(0);
                    break;
                default:
                    System.out.println("Reintroduceti o litera valida! ");
                    break;
            }

        }
    }

    public static int Convert(int number) {

        if (number == 0)
            return 0;

        else

            return (number % 2 + 10 * Convert(number / 2));
    }
    public static void Tabel(int[] arr, int size, int i)
    {

        if (i <0) {
            System.out.println("\n");;
            return ;
        }else{

        System.out.println(arr[i]+" ");

        i--;
        Tabel(arr, size, i--);}
    }
    public static void Lista(List<String> al, int i)
    {

        if (i <0) {
            System.out.println("\n");;
            return ;
        }else{

            System.out.println(al.get(i)+" ");

            i--;
            Lista(al, i--);}
    }
    public static void Fisier(List<String> fileStream, List<String> outputstream, int i) throws IOException {
        if (i <0) {
            System.out.println("\n");;
            return ;
        }else{

            outputstream.add(fileStream.get(i));

            i--;

            Fisier(fileStream,outputstream, i--);}


    }

}
