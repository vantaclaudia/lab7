package com.company;

import java.util.Scanner;

class Combination {


    static void combinationUtil(String arr[], String data[], int start,
                                int end, int index, int r) {
        if (index == r) {
            for (int j = 0; j < r; j++)
                System.out.print(data[j] + ", ");
            System.out.println("");
            return;
        }


        for (int i = start; i <= end && end - i + 1 >= r - index; i++) {
            data[index] = arr[i];
            combinationUtil(arr, data, i + 1, end, index + 1, r);
        }
    }


    static void printCombination(String arr[], int n, int r) {

        String data[] = new String[r];

        combinationUtil(arr, data, 0, n-1 , 0, r);
    }

    /*Driver function to check for above function*/
    public static void main(String[] args) {
        System.out.print("Numarul de elemente ale tabloului sunt: \n");
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        String arr[] = new String[100];
        for(int i = 0;i<n;i++){
            System.out.print("\n    Elementul " + i +  ": ");
            arr[i] = sc.next();

        }





            printCombination(arr, n, 5);

    }
}
