package com.company;

import java.util.Scanner;

class Combination {


    static void combinationUtil(int arr[], int data[], int start,
                                int end, int index, int r) {
        if (index == r) {
            for (int j = 0; j < r; j++)
                System.out.print(data[j] + " ");
            System.out.println("");
            return;
        }


        for (int i = start; i <= end && end - i + 1 >= r - index; i++) {
            data[index] = arr[i];
            combinationUtil(arr, data, i + 1, end, index + 1, r);
        }
    }


    static void printCombination(int arr[], int n, int r) {

        int data[] = new int[r];

        combinationUtil(arr, data, 0, n - 1, 0, r);
    }

    public static void main(String[] args) {
        System.out.print("Numarul de elemente ale tabloului este: ");
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int arr[] = new int[100];
        for(int i = 0;i<n;i++){
            System.out.print("\n    Elementul "+i+" : ");
            arr[i] = sc.nextInt();

        }

        System.out.print("\nNumarul de elemente in combinatie este: ");
        int r = sc.nextInt();
        if(r>n){
            System.out.println("Rulati din nou programul, folosind parametrii corespunzatori.");

        }
        else {


            printCombination(arr, n, r);
        }
    }
}
